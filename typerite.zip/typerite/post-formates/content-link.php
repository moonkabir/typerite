<article class="masonry__brick entry format-link animate-this">
    <div class="entry__thumb">
        <div class="link-wrap">
            <?php the_excerpt(); ?>
            <cite>
                <a target="_blank" href="https://www.dreamhost.com/r.cgi?287326">https://www.dreamhost.com</a>
            </cite>
        </div>
    </div>
</article> <!-- end article -->
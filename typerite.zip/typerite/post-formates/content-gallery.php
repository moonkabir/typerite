<?php 
    $src1 = get_field("image1"); 
    $src2 = get_field("image2"); 
    $src3 = get_field("image3"); 
?>
<article class="masonry__brick entry format-gallery animate-this" <?php post_class(); ?>> 
    <div class="entry__thumb slider">
        <div class="slider__slides">
            <div class="slider__slide">
                <img src="<?php echo esc_url($src1); ?>" alt="img" >
            </div>
            <div class="slider__slide">
                <img src="<?php echo esc_url($src2); ?>" alt="img" >
            </div>
            <div class="slider__slide">
                <img src="<?php echo esc_url($src3); ?>" alt="img" >
            </div>
        </div>
    </div>                    
    <div class="entry__text">
        <div class="entry__header">
            <h2 class="entry__title"><a href="<?php echo get_the_permalink(); ?>"><?php the_title(); ?></a></h2>
            <div class="entry__meta">
                <span class="entry__meta-cat"> 
                    <a href="category.html"><?php the_category(); ?></a>
                </span>
                <span class="entry__meta-date">
                    <a href="single-standard.html"><?php echo get_the_date(); ?></a>
                </span>
            </div>
        </div>
        <div class="entry__excerpt">
            <p><?php the_excerpt(); ?></p>
        </div>
    </div>
</article>
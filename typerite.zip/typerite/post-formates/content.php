
                    <article class="masonry__brick entry format-standard animate-this" <?php post_class(); ?>>   
                        <div class="entry__thumb">
                            <a href="<?php the_permalink(); ?>" class="entry__thumb-link">
                                <?php 
                                    if(has_post_thumbnail()){
                                        the_post_thumbnail();
                                    }
                                ?>
                            </a>
                        </div>
                        <div class="entry__text">
                            <div class="entry__header">
                                <h2 class="entry__title"><a href="<?php echo get_the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                <div class="entry__meta">
                                    <span class="entry__meta-cat"> 
                                        <a href="category.html"><?php the_category(); ?></a>
                                    </span>
                                    <span class="entry__meta-date">
                                        <a href="single-standard.html"><?php echo get_the_date(); ?></a>
                                    </span>
                                </div>
                            </div>
                            <div class="entry__excerpt">
                                <p><?php the_excerpt(); ?></p>
                            </div>
                        </div>
                    </article>
<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
    <!--- basic page needs
    ================================================== -->
    <meta charset="utf-8">
    <title><?php bloginfo( 'name' ); ?></title>
<?php wp_head(); ?>
</head>
<body <?php body_class();?>>
    <div id="top" class="s-wrap site-wrapper">
        <!-- site header
        ================================================== -->
        <header class="s-header">
            <div class="header__top">
                <div class="header__logo">
                    <a class="site-logo" href="index.html">
                        <img src="images/logo.svg" alt="Homepage">
                    </a>
                </div>
                <div class="header__search">
                    <form role="search" method="get" class="header__search-form" action="#">
                        <label>
                            <span class="hide-content">Search for:</span>
                            <input type="search" class="header__search-field" placeholder="Type Keywords" value="" name="s" title="Search for:" autocomplete="off">
                        </label>
                        <input type="submit" class="header__search-submit" value="Search">
                    </form>
                    <a href="#0" title="Close Search" class="header__search-close">Close</a>
                </div>  <!-- end header__search -->
                <!-- toggles -->
                <a href="#0" class="header__search-trigger"></a>
                <a href="#0" class="header__menu-toggle"><span>Menu</span></a>
            </div> <!-- end header__top -->
            <nav class="header__nav-wrap">

                <?php wp_nav_menu(array(
                        'theme_location' => 'main-menu',
                        'menu' => '',
                        'container' => '',
                        'container_class' => '',
                        'container_id' => '',
                        'menu_class' => 'header__nav',
                        'menu_id' => 'main-nav',
                        'echo' => true,
                        'before' => '',
                        'after' => '',
                        'link_before' => '',
                        'link_after' => '',
                        'items_wrap' => '<ul id = "%1$s" class = "%2$s">%3$s</ul>',
                        'walker' => new typerite_Nav_Primary_Walker()
                    )); ?>
                    <?php 
                        if(is_active_sidebar( "menu-social" )){
                            dynamic_sidebar("menu-social");
                        }
                    ?>
            </nav> <!-- end header__nav-wrap -->
        </header> <!-- end s-header -->
<?php 
require get_template_directory() . '/inc/nav-walker.php';
function typerite_setup_theme(){
	add_theme_support('title-tag');
	add_theme_support(
		'post-formats',
		array(
			'image',
			'gallery',
			'link',
			'video',
			'audio',
			'quote',
		)
	);
	add_theme_support('post-thumbnails');
	register_nav_menus(array(
        'main-menu' => __('Primary Menu', 'typerite')
	));
	register_nav_menu( "socialmenu", __( "Social Menu", "typerite" ));
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'caption',
		)
	);
	add_theme_support('custom-logo');
	add_theme_support('custom-background');
	add_theme_support('customize-selective-refresh-widgets');
	add_theme_support('custom-header');
}
add_action( "after_setup_theme", "typerite_setup_theme" );

function typerite_scripts(){
	wp_enqueue_style( "base", get_theme_file_uri("/assets/css/base.css"));
	wp_enqueue_style( "vendor", get_theme_file_uri("/assets/css/vendor.css"));
	wp_enqueue_style( "main", get_theme_file_uri("/assets/css/main.css"));
	wp_enqueue_style( "launcher", get_stylesheet_uri(),null,"0.1" );
	wp_enqueue_script( "plugins-js", get_theme_file_uri("/assets/js/plugins.js"),array( "jquery" ), '1.0.0', true );
	wp_enqueue_script( "main-js", get_theme_file_uri("/assets/js/main.js"),array( "jquery" ), '1.0.0', true );
}
add_action( "wp_enqueue_scripts", "typerite_scripts" );

function typerite_sider_widgets(){
	register_sidebar( 
		array( 
			'name'          => __( 'Footer left', 'typerite' ),
            'id'            => 'footer-left',
            'description'   => __( 'Footer left', 'typerite' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
		) 
	);

	register_sidebar( 
		array( 
			'name'          => __( 'Footer right', 'typerite' ),
            'id'            => 'footer-right',
            'description'   => __( 'Footer right', 'typerite' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
		) 
	);

	register_sidebar( 
		array( 
			'name'          => __( 'Contact Footer right', 'typerite' ),
            'id'            => 'contact-footer-right',
            'description'   => __( 'Contact Footer right', 'typerite' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
		) 
	);

	register_sidebar( 
		array( 
			'name'          => __( 'Contact Footer left', 'typerite' ),
            'id'            => 'contact-footer-left',
            'description'   => __( 'Contact Footer left', 'typerite' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
		) 
	);

	register_sidebar( 
		array( 
			'name'          => __( 'About Footer left 1', 'typerite' ),
            'id'            => 'about-footer-left-1',
            'description'   => __( 'About Contact Footer left 1', 'typerite' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
		) 
	);
	register_sidebar( 
		array( 
			'name'          => __( 'About Footer right 1', 'typerite' ),
            'id'            => 'about-footer-right-1',
            'description'   => __( 'About Contact Footer right 1', 'typerite' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
		) 
	);
	register_sidebar( 
		array( 
			'name'          => __( 'About Footer left 2', 'typerite' ),
            'id'            => 'about-footer-left-2',
            'description'   => __( 'About Contact Footer left 2', 'typerite' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
		) 
	);
	register_sidebar( 
		array( 
			'name'          => __( 'About Footer right 2', 'typerite' ),
            'id'            => 'about-footer-right-2',
            'description'   => __( 'About Contact Footer right 2', 'typerite' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
		) 
	);
	register_sidebar( 
		array( 
			'name'          => __( 'Menu social', 'typerite' ),
            'id'            => 'menu-social',
            'description'   => __( 'Menu social', 'typerite' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
		) 
	);
}
add_action( "widgets_init", "typerite_sider_widgets");



/*	function ci_get_related_posts( $post_id, $related_count, $args = array() ) {
		$args = wp_parse_args( (array) $args, array(
			'orderby' => 'rand',
			'return'  => 'query', // Valid values are: 'query' (WP_Query object), 'array' (the arguments array)
		) );

		$related_args = array(
			'post_type'      => get_post_type( $post_id ),
			'posts_per_page' => 3,
			'post_status'    => 'publish',
			'post__not_in'   => array( $post_id ),
			'orderby'        => $args['orderby'],
			'tax_query'      => array()
		);

		$post       = get_post( $post_id );
		$taxonomies = get_object_taxonomies( $post, 'names' );

		foreach ( $taxonomies as $taxonomy ) {
			$terms = get_the_terms( $post_id, $taxonomy );
			if ( empty( $terms ) ) {
				continue;
			}
			$term_list                   = wp_list_pluck( $terms, 'slug' );
			$related_args['tax_query'][] = array(
				'taxonomy' => $taxonomy,
				'field'    => 'slug',
				'terms'    => $term_list
			);
		}

		if ( count( $related_args['tax_query'] ) > 1 ) {
			$related_args['tax_query']['relation'] = 'OR';
		}

		if ( $args['return'] == 'query' ) {
			return new WP_Query( $related_args );
		} else {
			return $related_args;
		}
	}*/









?>
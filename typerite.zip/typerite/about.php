<?php 
/*
Template Name:about
*/

get_header();
while (have_posts()) {
	the_post();
}
?>
        <!-- site content
        ================================================== -->
        <div class="s-content content">
            <main class="row content__page">
                
                <section class="column large-full entry format-standard">

                    <div class="media-wrap">
                        <div>
                            <?php the_post_thumbnail(); ?>
                        </div>
                    </div>

                    <?php the_content(); ?>
                    <hr>
                    <div class="row block-large-1-2 block-tab-full">
                        <div class="column">
                            <?php 
                                if(is_active_sidebar( "about-footer-left-1" )){
                                    dynamic_sidebar("about-footer-left-1");
                                }
                            ?>
                        </div>
                        <div class="column">
                            <?php 
                                if(is_active_sidebar( "about-footer-right-1" )){
                                    dynamic_sidebar("about-footer-right-1");
                                }
                            ?>
                        </div>
                        <div class="column">
                            <?php 
                                if(is_active_sidebar( "about-footer-left-2" )){
                                    dynamic_sidebar("about-footer-left-2");
                                }
                            ?>
                        </div>
                        <div class="column">
                            <?php 
                                if(is_active_sidebar( "about-footer-right-2" )){
                                    dynamic_sidebar("about-footer-right-2");
                                }
                            ?>
                        </div>
                    </div>
                </section>
            </main>
        </div> <!-- end s-content -->
<?php get_footer(); ?>
        <!-- footer
        ================================================== -->
        <footer class="s-footer">
            <div class="row">
                <div class="column large-full footer__content">
                    <div class="footer__copyright">
                        <div>
                            <?php 
                                if(is_active_sidebar( "footer-left" )){
                                    dynamic_sidebar("footer-left");
                                }
                            ?>
                        </div> 
                        <span></span>
                        <div>
                            <?php 
                                if(is_active_sidebar( "footer-right" )){
                                    dynamic_sidebar("footer-right");
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="go-top">
                <a class="smoothscroll" title="Back to Top" href="#top"></a>
            </div>
        </footer>

    </div> <!-- end s-wrap -->
<?php wp_footer(); ?>
</body>
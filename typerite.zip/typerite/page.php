<?php
get_header();
?>
        <div class="s-content">
            <div class="masonry-wrap">
                <div class="masonry">
                    <div class="grid-sizer"></div>
                    <?php 
                        while (have_posts()) {
                            the_post();
                           the_content();
                        }
                    ?>
                </div> <!-- end masonry -->
            </div> <!-- end masonry-wrap -->
        </div> <!-- end s-content -->
<?php get_footer(); ?>
<?php 
/*
Template Name:contact
*/

get_header();
while (have_posts()) {
	the_post();
}
?>

        <!-- site content
        ================================================== -->
        <div class="s-content content">
            <main class="row content__page">
                <section class="column large-full entry format-standard">
                    <div class="media-wrap">
                        <div>
                            <?php the_post_thumbnail(); ?>
                        </div>
                    </div>
                    <?php the_content(); ?>
                    <div class="row">
						<div class="column large-six tab-full">
                            <?php 
                                if(is_active_sidebar( "contact-footer-left" )){
                                    dynamic_sidebar("contact-footer-left");
                                }
                            ?>
                        </div> 
                        <div class="column large-six tab-full">
                            <?php 
                                if(is_active_sidebar( "contact-footer-right" )){
                                    dynamic_sidebar("contact-footer-right");
                                }
                            ?>
                        </div>
                    </div>
                    <?php if ( !post_password_required() ): ?>
                        <div class="col-md-12">
                            <?php
                            comments_template();
                            ?>
                        </div>
                    <?php endif; ?>
                </section>
            </main>
        </div> <!-- end s-content -->
<?php get_footer(); ?>
<?php
get_header();
?>
        <div class="s-content">
            <div class="masonry-wrap">
                <div class="masonry">
                    <div class="grid-sizer"></div>
                    <?php 
                        while (have_posts()) {
                            the_post();
                            get_template_part( "post-formates/content", get_post_format());
                        }
                    ?>
                </div> <!-- end masonry -->
            </div> <!-- end masonry-wrap -->
            <div class="row">
                <div class="column large-full">
                    <nav class="pgn">
                        <ul>
                            <?php 
                                the_posts_pagination( 
                                    array( 
                                        'screen_reader_text' => ' ',
                                        'mid_size'  => 2,
                                        'prev_text' => __( 'Prev', 'typerite' ),
                                        'next_text' => __( 'next', 'typerite' ),
                                    ) );
                            ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div> <!-- end s-content -->
<?php get_footer(); ?>
<?php get_header();?> 
        <!-- site content
        ================================================== -->
        <div class="s-content content">
            <main class="row content__page">
                <?php while (have_posts()) {
                    the_post();
                } ?>
                <?php 
                    if(get_post_format() == "gallery"){

                        $src1 = get_field("image1"); 
                        $src2 = get_field("image2"); 
                        $src3 = get_field("image3"); 
                ?>
                <article class="column large-full entry format-gallery" <?php post_class(); ?>>
                    <div class="media-wrap entry__media">
                        <div class="entry__slider slider">
                            <div class="slider__slides">
                                <div class="slider__slide">
                                    <img src="<?php echo esc_url($src1); ?>" alt="img" >
                                </div>
                                <div class="slider__slide">
                                    <img src="<?php echo esc_url($src2); ?>" alt="img" >
                                </div>
                                <div class="slider__slide">
                                    <img src="<?php echo esc_url($src3); ?>" alt="img" >
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php
                    }elseif(get_post_format() == "video"){
                         $src = get_field("videolink"); ?>
                        <article class="column large-full entry format-video"<?php post_class(); ?>>
                        <div class="media-wrap entry__media">
                            <div class="video-container">
                                <iframe src="<?php echo esc_url($src); ?>" width="640" height="360" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
                            </div>
                        </div>
                    <?php
                    }elseif (get_post_format() == "audio") {
                         $src = get_field("audiolink"); ?>
                        <article class="column large-full entry format-audio"<?php post_class(); ?>>
                        <div class="media-wrap entry__media">
                            <iframe width="100%" height="166" scrolling="no" frameborder="no" allow="autoplay" src="<?php echo esc_url($src); ?>"></iframe>
                        </div>
                    <?php
                    }else{
                        ?>
                        <article class="column large-full entry format-standard">
                            <div class="media-wrap entry__media">
                                <div class="entry__post-thumb">
                                    <?php 
                                        if(has_post_thumbnail()){
                                            the_post_thumbnail("full");
                                        }
                                    ?>
                                </div>
                            </div>
                    <?php
                    }
                    ?>
                    <div class="content__page-header entry__header">
                        <h1 class="display-1 entry__title">
                        <?php the_title(); ?>
                        </h1>
                        <ul class="entry__header-meta">
                            <li class="author">By <a href="#0"><?php echo get_the_author_meta( "display_name" ); ?></a></li>
                            <li class="date"><?php echo get_the_date(); ?></li>
                            <li class="cat-links">
                                <?php the_category(); ?>
                            </li>
                        </ul>
                    </div> <!-- end entry__header -->
                    <div class="entry__content">
                        <?php the_content(); ?>
                        <p class="entry__tags">
                            <span>
                                <?php _e("Post Tags","philosophy"); ?> 
                                <?php echo get_the_tag_list( "<ul class=\"entry__tag-list list-unstyled tag-class\"><li>", "</li><li>", "</li></ul>" ); ?>
                            </span>
            
                        </p>
                    </div> <!-- end entry content -->
                    <div class="entry__pagenav">
                        <div class="entry__nav">
                            <div class="entry__prev">
                                <span>
                                    <?php previous_post_link('%link', esc_html('Previous Post', 'typerite'));
                                    ?>  
                                </span>
                                <br>
                                <?php previous_post_link( '<strong>%link</strong>' ); ?>
                            </div>
                            <div class="entry__next">
                                <span>
                                    <?php next_post_link('%link', esc_html('Next Post', 'typerite'));
                                    ?>
                                </span>
                                <br>
                                <?php next_post_link( '<strong>%link</strong>' ); ?>
                            </div>
                        </div>
                    </div> <!-- end entry__pagenav -->
                    <!-- related post start -->
                    <?php
                        $terms = get_the_terms( get_the_ID(), 'category' );
                        if( empty( $terms ) ) $terms = array();
                        $term_list = wp_list_pluck( $terms, 'slug' );
                        $related_args = array(
                            'post_type' => 'post',
                            'posts_per_page' => 3,
                            'post_status' => 'publish',
                            'post__not_in' => array( get_the_ID() ),
                            'orderby' => 'rand',
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'category',
                                    'field' => 'slug',
                                    'terms' => $term_list
                                )
                            )
                        );
                        $related = new WP_Query( $related_args );

                        if( $related->have_posts() ) :
                        ?>
                        <div class="entry__related">
                            <h3 class="h2">
                                <?php _e("Related posts","philosophy"); ?>
                            </h3>
                            <ul class="related">
                                <?php while( $related->have_posts() ): $related->the_post();?>
                                <li class="related__item">
                                    <a href=" <?php echo get_the_permalink(); ?> " class="related__link">
                                        <?php the_post_thumbnail( 'post-thumbnail', '' ); ?>
                                    </a>
                                    <h5 class="related__post-title"><?php the_title(); ?></h5>   
                                </li>
                                <?php endwhile; ?>
                            </ul>
                        </div>
                        <?php
                        endif;
                        wp_reset_postdata();
                    ?>
                    <!-- related post end -->
                </article> <!-- end column large-full entry-->       
                <!-- comment section -->     
                    <?php
                        if(!post_password_required()){
                            comments_template();
                        }
                    ?>
            </main>
        </div> <!-- end s-content -->
<?php get_footer(); ?>
